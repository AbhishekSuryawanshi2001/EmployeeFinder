-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2023 at 07:17 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arttt`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `id` int(10) NOT NULL,
  `u_card` varchar(12) NOT NULL,
  `u_f_name` text NOT NULL,
  `u_l_name` text NOT NULL,
  `u_father` text NOT NULL,
  `u_aadhar` varchar(12) NOT NULL,
  `u_birthday` text NOT NULL,
  `u_gender` varchar(6) NOT NULL,
  `u_email` text NOT NULL,
  `u_phone` varchar(10) NOT NULL,
  `u_state` varchar(12) NOT NULL,
  `u_dist` text NOT NULL,
  `u_village` text NOT NULL,
  `u_police` text NOT NULL,
  `u_pincode` text NOT NULL,
  `file` longblob NOT NULL,
  `u_mother` varchar(30) NOT NULL,
  `u_family` text NOT NULL,
  `staff_id` varchar(12) NOT NULL,
  `image` varchar(150) NOT NULL,
  `uploaded` datetime NOT NULL,
  `image1` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `u_card`, `u_f_name`, `u_l_name`, `u_father`, `u_aadhar`, `u_birthday`, `u_gender`, `u_email`, `u_phone`, `u_state`, `u_dist`, `u_village`, `u_police`, `u_pincode`, `file`, `u_mother`, `u_family`, `staff_id`, `image`, `uploaded`, `image1`) VALUES
(153, '010101010101', 'prof.S.', 'Thakur', 'Y.', '2154867543', '1965-01-11', 'Male', 'sthakur@gmail.com', '2222222222', 'MCA Building', 'MCA department', 'ground floor  inside the computer lab 1', 'Room number 1', 'cabin no 2', '', 'Techer', 'teching profession', 'NIKHIL1234', 'thakur sir.jpg', '2023-06-21 20:34:06', 'ground floor.jpg'),
(156, '3333', 'prof .S.', 'Patil', 'V.', '345862795125', '1988-02-12', 'Male', 'sthakur@gmail.com', '9544544522', 'MCA Building', '', 'first floor', 'Room number 1', 'cabin no 2', '', 'Teacher', 'Teaching proffesion', 'vv22371', 'Screenshot 2023-05-28 095812.png', '2023-07-19 11:12:35', 'Screenshot 2023-06-24 232517.png'),
(157, '216545544511', 'Abhishek', 'Suryawanshi', ' Pundlik', '628171639422', '2023-07-05', 'Male', 'suryawanshiabhishek099@gmail.com', '9604679432', 'MCA Building', 'MCA department', 'ground floor inside the computer lab 1', 'Room number 5', 'cabin no 3', '', 'Teacher', 'abc', '1234', 'gran-turismo-7-game-4k-wallpaper-uhdpaper.com-894@1@f.jpg', '2023-07-21 09:40:37', 'wp10436564.webp'),
(158, '62477569', 'prof .S.', 'Thakur', '', '', '2023-08-15', 'Male', 'sthakur@gmail.com', '9544544522', 'MCA Building', 'MCA department', 'first floor', 'Room number 5', 'cabin no 2', '', 'sunita', 'aedrtfygubhinjokpl[[', 'NIKHIL1111', 'a44.jpg', '2023-08-14 23:05:49', '1109535.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`id`, `username`, `password`, `email`, `create_at`) VALUES
(1, 'Abhishek', '$2y$10$7.H7yAl5X8qy8P4ZHM5iqucKennYh4/YdbsWOREIVQnhPXjmEq2Ia', 'suryawanshiabhishek099@gmail.com', '2023-07-21 03:55:39'),
(2, 'nikhil', '$2y$10$/CaHQk1p81Vuab7igWHcGepvrF2wDYlR2yWpb5gagvxmQNk9H.Ri6', 'nikhilbholankar12@gmail.com', '2023-07-21 04:35:35'),
(3, 'Ashish', '$2y$10$olZMNEBvCseiUnrojCwqAOkBaeJcJ3lmRryORaB3ZrzfxjkDhExWK', 'nikhibholankar2001@gmail.com', '2023-08-14 17:31:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
