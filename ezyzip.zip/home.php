<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>
<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Employee Location Finder System</title>
    <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
 <header>
   <nav>
   <div class="navbar">
     <div class="logo">
       <img src="images/logo.jpg" alt="">
     </div>
     <ul class="menu">
        <li><a href="#">Home</a></li>
        <li><a href="#">Latest</a></li>
        <li><a href="#">Category</a></li>
         <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="Empployee/index.php">Empployee Finder</a></li>
      </ul>
      <div class="search-box">
        <input type="text" placeholder="Search here...">
        <a href="#"><i class="fas fa-search"></i></a>
      </div>
   </div>
   </nav>
   <div class="content">
     <div class="text-content">
       <div class="text">Hello,Welcome To The </div>
       <div class="name">Location Finder System</div>
       <div class="job">
         <div class="job">
           <span>Employee Location</span>
            <div class="typing-text">
              <span class="one"> Finder System,</span>
              <span class="two"> Finder System.</span>
            </div>
          </div>
       </div>
       <div class="buttons">
   <button>About Finder System</button>
   <button>Follow Finder System</button>
 </div>
     </div>
     <div class="girl">
       <img src="images/employee.jpg" alt="">
     </div>
   </div>
   <div class="media-icons">
    <a href="#"><i class="fab fa-facebook-f"></i></a>
    <a href="#"><i class="fab fa-twitter"></i></a>
    <a href="#"><i class="fab fa-linkedin-in"></i></a>
    <a href="#"><i class="fab fa-pinterest"></i></a>
  </div>
 </header>
</body>
</html>
